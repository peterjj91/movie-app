import React, { Component } from 'react';
import Cookies from 'universal-cookie';
import Header from './../Header';
import CallApi from './../../api/api';
import Login from '../Login';
import MoviesPage from '../pages/MoviesPage';

const cookies = new Cookies();

export const AppContext = React.createContext();

class App extends Component {
  constructor() {
    super();

    this.state = {
      auth: {
        user: null,
        session_id: null,
      },
      showModal: false,
    };
  }

  updateAuth = ({ user, session_id }) => {
    this.setState(prevState => ({
      auth: {
        ...prevState.auth,
        user,
        session_id,
      },
    }));

    cookies.set('session_id', session_id, {
      path: '/',
      maxAge: 2592000,
    });
  };

  onLogOut = () => {
    cookies.remove('session_id');
  };

  toggleModalLogin = () =>
    this.setState(prevState => ({
      showModal: !prevState.showModal,
    }));

  componentDidMount() {
    const session_id = cookies.get('session_id');

    if (session_id && session_id !== 'null') {
      CallApi.get(`/account`, {
        params: {
          session_id: session_id,
        },
      }).then(user => {
        this.updateAuth({ user, session_id });
        // this.getFavoriteMovies(user, session_id);
        // this.getMoviesWatchlist(user, session_id);
      });
    }
  }

  render() {
    const { showModal, auth } = this.state;

    return (
      <AppContext.Provider
        value={{
          auth: auth,
          updateAuth: this.updateAuth,
          onLogOut: this.onLogOut,
          toggleModalLogin: this.toggleModalLogin,
          showModal: showModal,
        }}
      >
        <Header />

        <MoviesPage />

        <Login />
      </AppContext.Provider>
    );
  }
}

export default App;
