import UISelect from './UISelect';

export default UISelect;
