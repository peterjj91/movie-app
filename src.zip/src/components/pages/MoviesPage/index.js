import MoviesPage from './MoviesPage';

export default MoviesPage;
