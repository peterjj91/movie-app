import React, { Component } from 'react';
import _ from 'lodash';
import Filters from '../../Filters';
import MoviesList from '../../Movies/MoviesList';
import AppContextHOC from '../../HOC/AppContextHOC';
import CallApi from '../../../api/api';

class MoviesPage extends Component {
  constructor() {
    super();

    this.initialState = {
      filters: {
        sort_by: 'popularity.desc',
        primary_release_year: new Date().getFullYear().toString(),
        with_genres: [],
        page: 1,
      },
      loadingFavoriteMovies: false,
      loadingMoviesWatchlist: false,
      favoriteMovies: [],
      moviesWatchlist: [],
      total_pages: 1,
    };

    this.state = this.initialState;
  }

  onChangeFilters = event => {
    const value = event.target.value;
    const name = event.target.name;

    this.setState(prevState => ({
      filters: {
        ...prevState.filters,
        [name]: value,
      },
    }));
  };

  onChangeTotalPage = pages => {
    this.setState({ total_pages: pages });
  };

  onToggleFavoriteMovies = () => {
    this.setState({
      loadingFavoriteMovies: !this.state.loadingFavoriteMovies,
    });
  };

  onToggleMoviesWatchlist = () => {
    this.setState({
      loadingMoviesWatchlist: !this.state.loadingMoviesWatchlist,
    });
  };

  onResetFilters = () => {
    this.setState(this.initialState);
  };

  getFavoriteMovies = (user, session_id) => {
    CallApi.get(`/account/${user.id}/favorite/movies`, {
      params: {
        session_id: session_id,
      },
    }).then(data => {
      this.setState({ favoriteMovies: data.results });
    });
  };

  getMoviesWatchlist = (user, session_id) => {
    CallApi.get(`/account/${user.id}/watchlist/movies`, {
      params: {
        session_id: session_id,
      },
    }).then(data => {
      this.setState({ moviesWatchlist: data.results });
    });
  };

  toggleModalLogin = () =>
    this.setState(prevState => ({
      showModal: !prevState.showModal,
    }));

  componentDidUpdate(prevProps, prevState) {
    // const { loadingFavoriteMovies, loadingMoviesWatchlist } = this.state;
    // const {
    //   auth: { user, session_id },
    // } = this.props;
    // if (!_.isEqual(prevState.auth, this.state.auth) && user) {
    //   this.getFavoriteMovies(user, session_id);
    //   this.getMoviesWatchlist(user, session_id);
    // }
    // if (prevState.loadingFavoriteMovies !== loadingFavoriteMovies) {
    //   this.getFavoriteMovies(user, session_id);
    // }
    // if (prevState.loadingMoviesWatchlist !== loadingMoviesWatchlist) {
    //   this.getMoviesWatchlist(user, session_id);
    // }
  }

  // componentDidMount() {
  //   const session_id = cookies.get('session_id');

  //   if (session_id && session_id !== 'null') {
  //     CallApi.get(`/account`, {
  //       params: {
  //         session_id: session_id,
  //       },
  //     }).then(user => {
  //       this.updateAuth({ user, session_id });
  //       this.getFavoriteMovies(user, session_id);
  //       this.getMoviesWatchlist(user, session_id);
  //     });
  //   }
  // }

  render() {
    const {
      filters,
      total_pages,
      favoriteMovies,
      moviesWatchlist,
    } = this.state;
    const { auth } = this.props;

    return (
      <div className="container-fluid">
        <div className="row mt-4">
          <div className="col-4">
            <div className="card">
              <div className="card-body">
                <h3>Фильтры:</h3>
                <Filters
                  filters={filters}
                  onChangeFilters={this.onChangeFilters}
                  total_pages={total_pages}
                  onResetFilters={this.onResetFilters}
                />
              </div>
            </div>
          </div>
          <div className="col-8">
            <MoviesList
              filters={filters}
              total_pages={total_pages}
              onChangeTotalPage={this.onChangeTotalPage}
              onChangeFilters={this.onChangeFilters}
              favoriteMovies={favoriteMovies}
              moviesWatchlist={moviesWatchlist}
              toggleModalLogin={this.toggleModalLogin}
              onToggleFavoriteMovies={this.onToggleFavoriteMovies}
              onToggleMoviesWatchlist={this.onToggleMoviesWatchlist}
              auth={auth}
            />
          </div>
        </div>
      </div>
    );
  }
}

export default AppContextHOC(MoviesPage);
