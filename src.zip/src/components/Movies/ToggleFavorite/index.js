import ToggleFavorite from './ToggleFavorite';

export default ToggleFavorite;
