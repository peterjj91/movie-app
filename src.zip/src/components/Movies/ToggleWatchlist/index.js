import ToggleWatchlist from './ToggleWatchlist';

export default ToggleWatchlist;
