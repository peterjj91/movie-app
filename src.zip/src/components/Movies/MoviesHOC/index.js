import MoviesHOC from './MoviesHOC';

export default MoviesHOC;
