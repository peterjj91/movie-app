import MovieItem from './MovieItem';

export default MovieItem;
