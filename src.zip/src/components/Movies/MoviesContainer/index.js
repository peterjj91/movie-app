import MoviesContainer from './MoviesContainer';

export default MoviesContainer;
