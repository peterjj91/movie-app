import MoviesList from './MoviesList';

export default MoviesList;
